# CART3R Android Bridge — Phase 2

Phase 2 extends the Phase 1 device foundation for **Realme C71 RMX5303 / Android 16**. The existing application ID and dashboard visual style are retained.

## Phase 2 features

- Device identification and KernelSU root verification.
- Read-only CPU policy governor/current/min/max frequency inspection.
- Read-only Mali GPU devfreq inspection at `/sys/class/devfreq/23100000.gpu`.
- RAM and swap information from `/proc/meminfo`.
- Thermal zone readings from `/sys/class/thermal/thermal_zone*` (values are normalized from millidegrees when applicable).
- Kernel version and uptime.
- KernelSU module inspection from `/data/adb/modules` and `module.prop`, including disabled/pending-remove markers.
- Session audit entries for diagnostic refreshes.
- Manual **REFRESH DIAGNOSTICS** button.

## Security boundaries

- Root is used only for a fixed, app-authored diagnostic command and `id` verification.
- There is no user-entered shell, arbitrary command endpoint, network listener, or AI remote execution.
- This phase does not write system settings, change CPU/GPU frequencies, or enable/disable/remove modules.
- Module inspection is read-only. The audit list is currently session-only and resets when the app process is recreated.
- Root output is bounded and the command has a timeout.

## Build with GitHub Actions

1. Upload the contents of this ZIP to the repository root, replacing the Phase 1 source files.
2. Push to `main` or `master`, or open **Actions → Build CART3R Android Bridge → Run workflow**.
3. Download the `CART3R-Bridge-Phase2-debug` artifact from the completed workflow.
4. Extract `app-debug.apk` and install it over Phase 1. The application ID remains `com.cart3r.bridge`.

## Build locally

Requirements: JDK 17 and Gradle 8.9.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Technical details

- Application ID: `com.cart3r.bridge`
- Version: `2.0.0` (versionCode 2)
- minSdk: 26; targetSdk: 35; compileSdk: 35
- Kotlin 2.0.21; Android Gradle Plugin 8.7.3; Gradle 8.9

## Known device-specific assumptions

The GPU reader uses the Realme C71 Mali devfreq node `/sys/class/devfreq/23100000.gpu`. If a firmware update changes this path, the GPU line may report unavailable; the rest of the diagnostic report should still work. Some thermal zones may be inaccessible or absent and are skipped.
